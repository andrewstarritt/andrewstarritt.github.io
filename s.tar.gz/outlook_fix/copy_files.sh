#!/usr/bin/bash

sleep 4

cd /c/Users/starritta/outlook_fix

mkdir -p /c/Users/starritta/AppData/Roaming/Microsoft/Signatures/Aardvark_files

cp -rf Aardvark_files/*  /c/Users/starritta/AppData/Roaming/Microsoft/Signatures/Aardvark_files/

cp -f Aardvark.*         /c/Users/starritta/AppData/Roaming/Microsoft/Signatures/

echo 'aardvark copy complete'
sleep 54

# end
