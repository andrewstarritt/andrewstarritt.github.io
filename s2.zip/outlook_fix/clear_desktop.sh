#!/usr/bin/bash

sleep 4

cd /c/Users/starritta/Desktop

rm -f "Knowledge Tree.url"
rm -f "HardcatWeb.url"
#rm -f "Submit an IT Support Ticket.url"
rm -f "eEmployee Payroll.url"
rm -f "CiAnywhere-Payroll.url"
rm -f "Synchrotron Internet.url"
rm -f "T1 CES 11.09.lnk"
rm -f "iexplore.exe"
rm -f "Clayton Intranet.url"

echo 'clear desk top complete'
sleep 54

# end
